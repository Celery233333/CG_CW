#include <list>
#include <vector>
#include <algorithm>

#include "point.h"

point evaluate(float t, std::list<point> P)
{
	std::list<point> Q;
	// Q.assign(P.begin(), P.end());
	Q = P;

	while (Q.size() > 1)
	{
		std::list<point> R;
		
		auto it = Q.begin();
		while (it != std::prev(Q.end()))
		{
			point p = (1 - t) * (*it) + t * (*(std::next(it)));
			R.push_back(p);
			++it;
		} 

		Q.clear();
		Q = R;
	}

	return Q.front();
}

std::vector<point> EvaluateBezierCurve(std::vector<point>ctrl_points, int num_evaluations)
{
	std::list<point> ps(ctrl_points.begin(), ctrl_points.end());
	std::vector<point> curve;

	float offset = 1.f / float( num_evaluations);
	// printf("%f", offset);
	curve.push_back(ps.front());

	for (int e = 0; e < num_evaluations; e++)
	{
		// printf("%f\n", offset * (e + 1));
		point p = evaluate(offset * (e + 1), ps);
		// printf("%f %f %f\n", p.x, p.y, p.z);
		curve.push_back(p);
	}


	return curve;
}

float* MakeFloatsFromVector(std::vector<point> curve, int &num_verts, int &num_floats, float r, float g, float b)
{
	num_verts = curve.size();
	if (num_verts == 0)
	{
		return NULL;
	}
	num_floats = num_verts * 6;

	float *vertices = new float[num_floats];
	for (int i = 0; i < curve.size(); i++)
	{
		auto p1 = std::next(curve.begin(), i);
		vertices[i * 6] = (*p1).x;
		vertices[i * 6 + 1] = (*p1).y;
		vertices[i * 6 + 2] = (*p1).z;

		vertices[i * 6 + 3] = r;
		vertices[i * 6 + 4] = g;
		vertices[i * 6 + 5] = b;
	}

	return vertices;
}
