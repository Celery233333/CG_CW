#include <iostream>
#include <stdio.h>
#include<Windows.h>
void KeyCallback(GLFWwindow* window, int key, int scancode, int action, int mods) {
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);
	if (key == GLFW_KEY_LEFT && action == GLFW_REPEAT)
		x_offset -= 0.01f;
	if (key == GLFW_KEY_RIGHT && action == GLFW_REPEAT)
		x_offset += ��.01f;
	if (key == GLFW_KEY_UP && action == GLFW_REPEAT)
		y_offset += 0.01f;
	if (key == GLFW_KEY_DOWN && action == GLFW_REPEAT)
		y_offset -= 0.01f;
}